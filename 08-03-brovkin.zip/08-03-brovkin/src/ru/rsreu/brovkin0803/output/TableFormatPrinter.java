package ru.rsreu.brovkin0803.output;

import java.sql.Timestamp;
import java.util.List;

import com.prutzkow.resourcer.Resourcer;

import oracle.sql.TIMESTAMP;
import ru.rsreu.brovkin0803.dto.AverageSumPawnsDTO;
import ru.rsreu.brovkin0803.dto.PawnsDTO;
import ru.rsreu.brovkin0803.dto.PledgedClientsDTO;
import ru.rsreu.brovkin0803.entities.Client;
import ru.rsreu.brovkin0803.entities.Pawn;
import ru.rsreu.brovkin0803.entities.PawnCategory;

public class TableFormatPrinter {
	
	private TableFormatPrinter() {
		
	}
	
	public static void printTableFormatFirstQuery(List<PawnsDTO> pawnsDateInterval, Resourcer resourcer) {
		Timestamp startDate = new Timestamp(Long.parseLong(resourcer.getString("startDate")));
		Timestamp endDate = new Timestamp(Long.parseLong(resourcer.getString("finishDate")));
		System.out.printf(resourcer.getString("first.query.string"), 
				TIMESTAMP.toString(TIMESTAMP.toBytes(startDate)),
				TIMESTAMP.toString(TIMESTAMP.toBytes(endDate)));
		System.out.printf(resourcer.getString("first.query.format"), resourcer.getString("code"),
				resourcer.getString("surname"), resourcer.getString("name"),
				resourcer.getString("patronymic"), resourcer.getString("title"),
				resourcer.getString("amount"), resourcer.getString("delivery.date"));
		for (PawnsDTO pawns : pawnsDateInterval) {
			Client client = pawns.getClient();
			Pawn pawn = pawns.getPawn();
			PawnCategory pawnCategory = pawns.getPawnCategory();
			System.out.printf(resourcer.getString("first.query.format"), Integer.toString(pawn.getCode()),
					client.getSurname(), client.getName(), client.getPatronymic(),
					pawnCategory.getTitle(), Integer.toString(pawn.getAmount()),
					TIMESTAMP.toString(TIMESTAMP.toBytes(pawn.getDeliveryDate())));
		}
	}
	
	public static void printTableFormatSecondQuery(List<PledgedClientsDTO> pledgedClients, Resourcer resourcer) {
		System.out.printf(resourcer.getString("second.query.string"));
		System.out.printf(resourcer.getString("second.query.format"), resourcer.getString("surname"),
				resourcer.getString("name"), resourcer.getString("patronymic"),
				resourcer.getString("passport.number"), resourcer.getString("passport.series"), 
				resourcer.getString("title"), resourcer.getString("amount"));
		for (PledgedClientsDTO pledgedClient : pledgedClients) {
			Client client = pledgedClient.getClient();
			System.out.printf(resourcer.getString("second.query.format"), client.getSurname(),
					client.getName(), client.getPatronymic(), client.getPassportNumber(),
					client.getPassportSeries(), pledgedClient.getTitle(), pledgedClient.getAmount());
		}
	}
	
	public static void printTableFormatThirdQuery(List<AverageSumPawnsDTO> averageSumPawns, Resourcer resourcer) {
		System.out.printf(resourcer.getString("third.query.string"));
		System.out.printf(resourcer.getString("third.query.format"), resourcer.getString("month.name"),
				resourcer.getString("year.name"), resourcer.getString("sum.name"));
		for (AverageSumPawnsDTO averageSumPawn : averageSumPawns) {
			System.out.printf(resourcer.getString("third.query.format"),
					averageSumPawn.getDateMonth(), averageSumPawn.getDateYear(),
					Integer.toString(averageSumPawn.getAverageAmountPawn()));
		}
	}

}

package ru.rsreu.brovkin0803.datalayer;

import java.sql.Timestamp;
import java.util.List;

import ru.rsreu.brovkin0803.dto.AverageSumPawnsDTO;
import ru.rsreu.brovkin0803.dto.PawnsDTO;
import ru.rsreu.brovkin0803.dto.PledgedClientsDTO;

public interface PawnshopDAO {
	List<PawnsDTO> getPawnsCertainTimeInterval(Timestamp startInterval, Timestamp finalInterval);
	List<PledgedClientsDTO> getComplitedPawnClients();
	List<AverageSumPawnsDTO> getEachMonthAverageSumPawns();
}

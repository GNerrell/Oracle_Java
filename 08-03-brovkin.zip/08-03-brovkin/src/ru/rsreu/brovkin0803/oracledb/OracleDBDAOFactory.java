package ru.rsreu.brovkin0803.oracledb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.brovkin0803.datalayer.DAOFactory;

public class OracleDBDAOFactory extends DAOFactory {
	private static volatile OracleDBDAOFactory instance;
	private Connection connection;

	private OracleDBDAOFactory() {
	}

	public static OracleDBDAOFactory getInstance() throws ClassNotFoundException, SQLException {
		OracleDBDAOFactory factory = instance;
		if (instance == null) {
			synchronized (OracleDBDAOFactory.class) {
				instance = factory = new OracleDBDAOFactory();
				factory.connected();
			}
		}
		return factory;
	}

	private void connected() throws ClassNotFoundException, SQLException {
		Locale.setDefault(Locale.ENGLISH);
		// Class.forName("oracle.jdbc.driver.OracleDriver");
		Resourcer resourcer = ProjectResourcer.getInstance();
		String url = resourcer.getString("jdbc.driver.url");
		String user = resourcer.getString("user");
		String password = resourcer.getString("password");
		connection = DriverManager.getConnection(url, user, password);
		System.out.println(resourcer.getString("connected"));
	}

	@Override
	public OraclePawnshopDAO getOraclePawnshopDAO() {
		return new OraclePawnshopDAO(connection);
	}


}

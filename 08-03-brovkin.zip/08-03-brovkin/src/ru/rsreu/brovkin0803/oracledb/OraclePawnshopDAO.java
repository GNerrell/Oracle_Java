package ru.rsreu.brovkin0803.oracledb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.brovkin0803.datalayer.PawnshopDAO;
import ru.rsreu.brovkin0803.dto.AverageSumPawnsDTO;
import ru.rsreu.brovkin0803.dto.PawnsDTO;
import ru.rsreu.brovkin0803.dto.PledgedClientsDTO;
import ru.rsreu.brovkin0803.entities.Client;
import ru.rsreu.brovkin0803.entities.Pawn;
import ru.rsreu.brovkin0803.entities.PawnCategory;

public class OraclePawnshopDAO implements PawnshopDAO {

	private Connection connection;
	private Resourcer resourcer;

	public OraclePawnshopDAO(Connection connection) {
		this.connection = connection;
		this.resourcer = ProjectResourcer.getInstance();
	}

	@Override
	public List<PawnsDTO> getPawnsCertainTimeInterval(Timestamp startInterval, Timestamp finalInterval) {
		List<PawnsDTO> pawns = new ArrayList<PawnsDTO>();
		String queryCode = resourcer.getString("first.query");
		try {
			PreparedStatement query = connection.prepareStatement(queryCode);
			query.setTimestamp(1, startInterval);
			query.setTimestamp(2, finalInterval);
			ResultSet resultSet = query.executeQuery();
			while (resultSet.next()) {
				PawnsDTO currentPawn = new PawnsDTO(
						new Client(resultSet.getString(resourcer.getString("client.number")),
								resultSet.getString(resourcer.getString("surname")), 
								resultSet.getString(resourcer.getString("name")), 
								resultSet.getString(resourcer.getString("patronymic")), 
								resultSet.getString(resourcer.getString("passport.number")), 
								resultSet.getString(resourcer.getString("passport.series")), 
								resultSet.getString(resourcer.getString("commentary"))
								),
						new Pawn(resultSet.getInt(resourcer.getString("code")), 
								resultSet.getInt(resourcer.getString("category.code")), 
								resultSet.getString(resourcer.getString("client.code")), 
								resultSet.getString(resourcer.getString("description")),
								resultSet.getInt(resourcer.getString("amount")),
								resultSet.getInt(resourcer.getString("commision.fees")), 
								resultSet.getTimestamp(resourcer.getString("delivery.date")), 
								resultSet.getTimestamp(resourcer.getString("return.date"))
								), 
						new PawnCategory(resultSet.getInt(resourcer.getString("category.number")),
								resultSet.getString(resourcer.getString("title")),
								resultSet.getString(resourcer.getString("note"))
								)
						);
				pawns.add(currentPawn);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pawns;
	}

	@Override
	public List<PledgedClientsDTO> getComplitedPawnClients() {
		List<PledgedClientsDTO> pledgedClients = new ArrayList<PledgedClientsDTO>();
		String queryCode = resourcer.getString("second.query");
		try {
			PreparedStatement query = connection.prepareStatement(queryCode);
			ResultSet resultSet = query.executeQuery();
			while (resultSet.next()) {
				PledgedClientsDTO currentPledgedClients = new PledgedClientsDTO(
						new Client(resultSet.getString(resourcer.getString("client.number")),
								resultSet.getString(resourcer.getString("surname")), 
								resultSet.getString(resourcer.getString("name")), 
								resultSet.getString(resourcer.getString("patronymic")), 
								resultSet.getString(resourcer.getString("passport.number")), 
								resultSet.getString(resourcer.getString("passport.series")), 
								resultSet.getString(resourcer.getString("commentary"))
								),
								resultSet.getString(resourcer.getString("title")),
								resultSet.getInt(resourcer.getString("amount"))
						);
				pledgedClients.add(currentPledgedClients);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pledgedClients;
	}

	@Override
	public List<AverageSumPawnsDTO> getEachMonthAverageSumPawns() {
		List<AverageSumPawnsDTO> averageSumPawns = new ArrayList<AverageSumPawnsDTO>();
		String queryCode = resourcer.getString("third.query");
		try {
			PreparedStatement query = connection.prepareStatement(queryCode);
			ResultSet resultSet = query.executeQuery();
			while (resultSet.next()) {
				AverageSumPawnsDTO currentAverageSumPawn = new AverageSumPawnsDTO(
						resultSet.getString(resourcer.getString("month.name")),
						resultSet.getString(resourcer.getString("year.name")),
						resultSet.getInt(resourcer.getString("sum.name"))
						);
				averageSumPawns.add(currentAverageSumPawn);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return averageSumPawns;
	}




	}

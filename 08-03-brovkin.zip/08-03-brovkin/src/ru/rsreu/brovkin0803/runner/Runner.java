package ru.rsreu.brovkin0803.runner;

import java.sql.Timestamp;
import java.util.List;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.brovkin0803.datalayer.DAOFactory;
import ru.rsreu.brovkin0803.datalayer.DBType;
import ru.rsreu.brovkin0803.dto.AverageSumPawnsDTO;
import ru.rsreu.brovkin0803.dto.PawnsDTO;
import ru.rsreu.brovkin0803.dto.PledgedClientsDTO;
import ru.rsreu.brovkin0803.oracledb.OraclePawnshopDAO;
import ru.rsreu.brovkin0803.output.TableFormatPrinter;

public class Runner {
	
	private Runner() {
		
	}

	public static void main(String[] args) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		DAOFactory factory = DAOFactory.getInstance(DBType.ORACLE);
		OraclePawnshopDAO pawnshop = factory.getOraclePawnshopDAO();
		Timestamp startIntervalDate = new Timestamp(Long.parseLong(resourcer.getString("startDate"))); // 04.02.2020
		Timestamp endIntervalDate = new Timestamp(Long.parseLong(resourcer.getString("finishDate"))); // 01.01.2022 
		List<PawnsDTO> pawnsDateInterval = pawnshop.getPawnsCertainTimeInterval(startIntervalDate, endIntervalDate);
		TableFormatPrinter.printTableFormatFirstQuery(pawnsDateInterval, resourcer);
		List<PledgedClientsDTO> pledgedClients = pawnshop.getComplitedPawnClients();
		TableFormatPrinter.printTableFormatSecondQuery(pledgedClients, resourcer);
		List<AverageSumPawnsDTO> averageSumPawns = pawnshop.getEachMonthAverageSumPawns();
		TableFormatPrinter.printTableFormatThirdQuery(averageSumPawns, resourcer);
	}

}

package ru.rsreu.brovkin0803.entities;

public class PawnCategory {
	private int categoryNumber;
	private String title;
	private String note;
	
	public PawnCategory(int categoryNumber, String title, String note) {
		this.categoryNumber = categoryNumber;
		this.title = title;
		this.note = note;
	}

	public int getCategoryNumber() {
		return categoryNumber;
	}

	public String getTitle() {
		return title;
	}

	public String getNote() {
		return note;
	}
	
}

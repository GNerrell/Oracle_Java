package ru.rsreu.brovkin0803.entities;

import java.sql.Timestamp;

public class Pawn {
	private int code;
	private int categoryCode;
	private String clientCode;
	private String description;
	private int amount;
	private int commisionFees;
	private Timestamp deliveryDate;
	private Timestamp returnDate;
	
	public Pawn(int code, int categoryCode, String clientCode, String description, int amount,
			int commisionFees, Timestamp deliveryDate, Timestamp returnDate) {
		this.code = code;
		this.categoryCode = categoryCode;
		this.clientCode = clientCode;
		this.description = description;
		this.amount = amount;
		this.commisionFees = commisionFees;
		this.deliveryDate = deliveryDate;
		this.returnDate = returnDate;
	}

	public int getCode() {
		return code;
	}

	public int getCategoryCode() {
		return categoryCode;
	}

	public String getClientCode() {
		return clientCode;
	}

	public String getDescription() {
		return description;
	}

	public int getAmount() {
		return amount;
	}

	public int getCommisionFees() {
		return commisionFees;
	}

	public Timestamp getDeliveryDate() {
		return deliveryDate;
	}

	public Timestamp getReturnDate() {
		return returnDate;
	}
	
	
}

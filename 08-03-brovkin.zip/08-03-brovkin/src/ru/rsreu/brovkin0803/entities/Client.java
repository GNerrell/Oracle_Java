package ru.rsreu.brovkin0803.entities;

public class Client {
	private String clientNumber;
	private String surname;
	private String name;
	private String patronymic;
	private String passportNumber;
	private String passportSeries;
	private String commentary;

	public Client(String clientNumber, String surname, String name, String patronymic, String passportNumber,
			String passportSeries, String commentary) {
		this.clientNumber = clientNumber;
		this.surname = surname;
		this.name = name;
		this.patronymic = patronymic;
		this.passportNumber = passportNumber;
		this.passportSeries = passportSeries;
		this.commentary = commentary;
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public String getSurname() {
		return surname;
	}

	public String getName() {
		return name;
	}

	public String getPatronymic() {
		return patronymic;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public String getPassportSeries() {
		return passportSeries;
	}

	public String getCommentary() {
		return commentary;
	}
	
}
package ru.rsreu.brovkin0803.dto;

import ru.rsreu.brovkin0803.entities.Client;

public class PledgedClientsDTO {
	private Client client;
	private String title;
	private int amount;
	
	public PledgedClientsDTO(Client client, String title, int amount) {
		this.client = client;
		this.title = title;
		this.amount = amount;
	}
	
	public Client getClient() {
		return client;
	}

	public String getTitle() {
		return title;
	}

	public int getAmount() {
		return amount;
	}

}

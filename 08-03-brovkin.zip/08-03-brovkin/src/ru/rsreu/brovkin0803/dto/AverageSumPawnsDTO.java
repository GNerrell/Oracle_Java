package ru.rsreu.brovkin0803.dto;

public class AverageSumPawnsDTO {
	private String dateMonth;
	private String dateYear;
	private int averageAmountPawn;
	
	public AverageSumPawnsDTO(String dateMonth, String dateYear, int averageAmountPawn) {
		this.dateMonth = dateMonth;
		this.dateYear = dateYear;
		this.averageAmountPawn = averageAmountPawn;
	}

	public String getDateMonth() {
		return dateMonth;
	}

	public String getDateYear() {
		return dateYear;
	}

	public int getAverageAmountPawn() {
		return averageAmountPawn;
	}

	
}

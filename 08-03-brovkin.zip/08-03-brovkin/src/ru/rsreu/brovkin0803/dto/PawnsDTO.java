package ru.rsreu.brovkin0803.dto;

import ru.rsreu.brovkin0803.entities.Client;
import ru.rsreu.brovkin0803.entities.Pawn;
import ru.rsreu.brovkin0803.entities.PawnCategory;

public class PawnsDTO {
	private Client client;
	private Pawn pawn;
	private PawnCategory pawnCategory;
	
	public PawnsDTO(Client client, Pawn pawn, PawnCategory pawnCategory) {
		this.client = client;
		this.pawn = pawn;
		this.pawnCategory = pawnCategory;
	}

	public Client getClient() {
		return client;
	}

	public Pawn getPawn() {
		return pawn;
	}

	public PawnCategory getPawnCategory() {
		return pawnCategory;
	}
	

}
